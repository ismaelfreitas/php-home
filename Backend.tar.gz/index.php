<?php
$port = fopen('/dev/ttyACM0', 'w+');
usleep( 500000 );

if( isset( $_GET['temp'] ) ) {

	fwrite( $port, 't' );
	usleep( 500000 );
	
	$ret = fgets( $port );
	
	if( strlen($ret) > 0 && $ret != 'erro' ) {
	
		$sensor = explode( ',', $ret );
						
		echo json_encode(["temp"=>["t"=>$sensor[0],"u"=>$sensor[1]]]);
		
		//ex: {"temp":{"t":"26.44","u":"46.99"}}
	
	}else{
			
		echo json_encode(['error'=>["msg"=>"Falha ao obter temperatura."]]);
			
	}
	
}

if( isset( $_GET['rele'] ) ) {
		
	switch( $_GET['rele'] ) {
		
		case '10':
			$op = 'a'; //pin10
			break;
		case '11':
			$op = 'b'; //pin11
			break;
		case '12':
			$op = 'p'; //portao
			break;
		case '13':
			$op = 'd'; //alarme
			break;
		case 'all':
			$op = 's'; //status
			break;
		default:
			$op = $_GET['rele'];
			break;
		
	}
	
	fwrite( $port, $op );
	usleep( 500000 );
	
	$ret = fgets( $port );
	
	if( $_GET['rele'] == 'all' ) {
				
		if( strlen($ret) > 0 ) {
		
			$pins = explode( ',', substr($ret, 0, strlen($ret)-1) );
		
			$status = ["pins"=>[]];
				
			$count = 3;
		
			foreach( $pins as $key => $pin ) {

				$status["pins"][$count+''] = $pin;
			
				$count++;
					
			}
				
			echo json_encode($status);
			
			//ex: {"pins":{"3":"1","4":"0","5":"","6":"0","7":"0","8":"0","9":"0","10":"0","11":"1"}}
		
		}else{
			
			echo json_encode(['error'=>["msg"=>"Falha ao obter status."]]);
			
		}
				
	}else{	
		
		if( $ret == '0' || $ret == '1' ) {
			
			echo json_encode(['pins'=>[$_GET['rele']=>$ret]]);
			
			//ex: {"pins":{"3":"0"}}
			
		}else{
			
			echo json_encode(['error'=>["msg"=>"Falha ao obter status."]]);
			
		}
	
	}
	
}

fclose( $port );

?>
